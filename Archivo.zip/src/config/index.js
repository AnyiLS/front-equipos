import useStoreConfig from "./redux";

const useConfig = () => {
    return {
        useStoreConfig
    };
}

export default useConfig;